public class UPCScanner {

    private CashRegister cr;

    public UPCScanner(CashRegister cr){

        this.cr = cr;

    }

    public void scannedCode(String UPCCode){

        cr.setCurrentUPC(UPCCode);

    }
}
