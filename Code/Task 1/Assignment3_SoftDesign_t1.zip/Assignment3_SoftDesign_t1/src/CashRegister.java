import java.util.Scanner;

public class CashRegister {

    private String currentCode;
    private final Display display;
    private final TicketPrinter ticketPrinter;
    private ProductDB database;

    public CashRegister(Display display, TicketPrinter ticketPrinter){

        Scanner sc2 = new Scanner(System.in);

        currentCode ="";

        database = new ProductDB();

        this.display=display;
        this.ticketPrinter=ticketPrinter;

    }

    public void setCurrentUPC(String UPCcode){

        this.currentCode = UPCcode;

    }

    public void getProduct(){

        String info = database.getInfo(this.currentCode);

        display.displayText(info);
        ticketPrinter.displayText(info);
    }

}
