public class View {

    public default void displayText(String product){
        System.out.println("Register Display");
        System.out.println("__________________");
        System.out.println(product+"\n");
    }

}
