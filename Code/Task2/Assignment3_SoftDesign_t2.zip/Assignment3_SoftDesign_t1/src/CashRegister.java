import java.util.Scanner;

public class CashRegister {

    private String currentCode;
    private View view;
    private ProductDB database;

    public CashRegister(View view){

        Scanner sc2 = new Scanner(System.in);

        currentCode ="";

        database = new ProductDB();

        this.view=view;

    }

    public void setCurrentUPC(String UPCcode){

        this.currentCode = UPCcode;

    }

    public void getProduct(){

        String info = database.getInfo(this.currentCode);

        view.displayText(info);

    }

}
