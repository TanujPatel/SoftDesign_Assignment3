public class TicketPrinter implements View {

    public void displayText(String product){

        System.out.println("---------------------------------");
        System.out.println("              Ticket             ");
        System.out.println("---------------------------------");
        System.out.println();
        System.out.println(product);

    }

}
