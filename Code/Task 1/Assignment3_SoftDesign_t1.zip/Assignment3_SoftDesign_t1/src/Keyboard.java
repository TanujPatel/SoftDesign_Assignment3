public class Keyboard {

    private CashRegister cr;

    public Keyboard(CashRegister cr){

        this.cr = cr;

    }

    public void setUPC(String UPCCode){

        cr.setCurrentUPC(UPCCode);

    }
}
