public class ProductDB {

    public String getInfo(String productCode){

        String p="";


            if(productCode=="1") {
              p="Football        $10";
            }
            else   if(productCode=="2") {
                p="Soccerball        $10";
            }

            else{
                p="Invalid UPC";
            }

            return p;
    }
}
