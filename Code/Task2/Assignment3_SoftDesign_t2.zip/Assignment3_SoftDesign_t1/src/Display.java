public class Display implements View {

    public void displayText( String productInfo){

        System.out.println("              Register           ");
        System.out.println("---------------------------------");
        System.out.println(productInfo);

    }

}
