import java.util.Scanner;

public class MainController {

    Scanner sc = new Scanner(System.in);


    Display display = new Display();
    TicketPrinter ticketPrinter = new TicketPrinter();
    CashRegister cashRegister = new CashRegister(display, ticketPrinter);
    Keyboard keyboard = new Keyboard(cashRegister);
    UPCScanner scanner = new UPCScanner(cashRegister);

    String scannedItem;
    String manualScanned;
    int userid = 0;

    Scanner s= new Scanner(System.in);


    while(userid != 3){

        System.out.println("If you would like to start a session choose the following 2 options");
        System.out.println("Enter 1 to scan the UPS code of item");
        System.out.println("Enter 2 to manually enter the UPS code of item");
        System.out.println();
        System.out.println("If you would like to end the session enter 3");

        userid =sc.nextInt();

        if(userid ==1){

            System.out.println("Please enter the scanned items UPC code");
            scannedItem=sc.next();
            scanner.scannedCode(scannedItem);

        }

        else if(userid ==2){

            System.out.println("Please manually enter the UPC code for the item");
            manualScanned=sc.next();
            keyboard.setUPC(manualScanned);

        }

        else if(userid ==3){

            break;

        }

        else{

            System.out.println("Your input was invalid please try again");
            continue;

        }

        cashRegister.getProduct();

    }




}
